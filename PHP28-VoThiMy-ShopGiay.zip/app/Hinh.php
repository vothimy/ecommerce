<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hinh extends Model
{
    protected $table = 'hinhanh';
    protected $primaryKey = 'id';
        public $timestamps = false;
}
