<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HTTT extends Model
{
    protected $table = 'pttt';
    protected $primaryKey = 'id';
    public $timestamps = false;
}
