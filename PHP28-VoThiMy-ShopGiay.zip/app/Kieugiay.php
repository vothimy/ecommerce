<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kieugiay extends Model
{
    protected $table = 'kieugiay';
    protected $primaryKey = 'id';
        public $timestamps = false;
}
