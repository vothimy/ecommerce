<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CTGiay extends Model
{
    protected $table = 'ctsp';
    protected $primaryKey = 'id';
        public $timestamps = false;
}
