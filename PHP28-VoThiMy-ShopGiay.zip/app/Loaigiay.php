<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Loaigiay extends Model
{
    protected $table = 'loaisp';
    protected $primaryKey = 'id';
    public $timestamps = false;
}
