@include('templates.public.header')

  @yield('main-content')

@include('templates.public.rightbar')

				<div class="clearfix"> </div>
			</div>
		</div>
	</div>

@include('templates.public.footer')  
  