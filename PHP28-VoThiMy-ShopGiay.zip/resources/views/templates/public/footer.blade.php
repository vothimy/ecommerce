<!--start-footer-->
    <div class="footer">
        <div class="container">
        </div>
    </div>
    <!--end-footer-->
    <!--end-footer-text-->
    <div class="footer-text">
        <div class="container">
            <div class="footer-main">
                <p class="footer-class">Dự án web thương mại - Trung tâm đào tạo lập trình VinaEnter - Code by Võ Thị Mỹ - Lớp:PHP28 <a href="https://www.facebook.com/doremon.vo.3">DauVtm</p>
            </div>
        </div>
        <script type="text/javascript">
            $(document).ready(function() {
                
                // var defaults = {
                //     containerID: 'toTop', // fading element id
                //     containerHoverID: 'toTopHover', // fading element hover id
                //     scrollSpeed: 1200,
                //     easingType: 'linear' 
                // };
                
                
                // $().UItoTop({ easingType: 'easeOutQuart' });
                
            });
        </script>
        <a href="#home" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
    </div>
    <!--end-footer-text-->  
</body>
</html>