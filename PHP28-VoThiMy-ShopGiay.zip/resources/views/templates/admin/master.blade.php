@include('templates.admin.header')
@include('templates.admin.leftbar')
  @yield('main-content')
  	


@include('templates.admin.footer')  
  