

</div>

</div>
<!--content-->
<div class="footer">
	<p> Dự án web thương mại - Trung tâm đào tạo lập trình VinaEnter - Code by Võ Thị Mỹ - Lớp:PHP28  <a href="https://www.facebook.com/doremon.vo.3">DauVtm</a></p>
</div>
</div>
</div>
<!--//content-inner-->

</body>
</html>