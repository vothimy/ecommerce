<?php echo $__env->make('templates.admin.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.admin.leftbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->yieldContent('main-content'); ?>
  	


<?php echo $__env->make('templates.admin.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
  