<?php echo $__env->make('templates.public.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--start-ckeckout-->
<div class="ckeckout">
	<div class="container">
		<div class="ckeckout-top">
			<div class=" cart-items heading">
				<h3>Nhập thông tin của bạn</h3>
				<div class="in-check" >
					<form role="form" action="<?php echo e(route('public.giay.dathang')); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					<?php 
						$fullname ='';
						$email ='';
						$address ='';
						if(Auth::user() != ''){
							$arUser = Auth::user();
							$fullname  = $arUser->fullname;
							$email = $arUser->email;
							$address = $arUser->address;
						}
					?>
					  <div class="form-group">
					    <label for="exampleInputEmail1">Họ và tên</label>
					    <input type="text" name="fullname" required class="form-control" id="exampleInputEmail1" value="<?php echo e($fullname); ?>" placeholder="Họ và tên">
					  </div>
					  <div class="form-group">
					    <label for="exampleInputPassword1">Địa chỉ</label>
					    <input type="text" name="address" required class="form-control" id="exampleInputPassword1" value="<?php echo e($address); ?>" placeholder="Địa chỉ">
					  </div>
					  <div class="form-group">
					    <label for="exampleInputPassword1">Email</label>
					    <input type="text" name="email" required class="form-control" id="exampleInputPassword1" value="<?php echo e($email); ?>" placeholder="Email">
					  </div>
					  <button type="submit" class="btn btn-default">Xác nhận</button>
					</form>
				</div>
			</div>  
		</div>
	</div>
</div>
<hr>
<?php echo $__env->make('templates.public.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
