<?php $__env->startSection('main-content'); ?>
<img src="<?php echo e($publicUrl); ?>/images/loi404.jpg" height="400px" width="600px">
<a href="<?php echo e(route('public.index.index')); ?>">Quay về trang chủ</a>
<?php $__env->stopSection(); ?>		
<?php echo $__env->make('templates.public.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>