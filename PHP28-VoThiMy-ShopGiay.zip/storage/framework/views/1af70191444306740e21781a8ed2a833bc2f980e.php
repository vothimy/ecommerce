
<?php echo $__env->make('templates.public.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php if($arItems->hinhthuc == 'Phương thức thanh toán tại nhà'): ?>
<a href="<?php echo e(route('public.index.index')); ?>">Quay về trang chủ</a>
<?php endif; ?>
	<div class="wrapper-order">
		<div class="ckeckout">
			<div class="container">
				<div class="ckeckout-top">
					<h4>THÔNG TIN ĐƠN HÀNG VỪA ĐẶT</h4>
					<div class="info">
						<p><b>ID hóa đơn</b> : <?php echo e($arItems->id); ?></p>
						<p><b>Tên khách hàng</b> : <?php echo e($arItems->tenkh); ?></p>
						<p><b>Địa chỉ</b> : <?php echo e($arItems->noigiao); ?></p>
						<p><b>Ngày đặt hàng</b> : <?php echo e($arItems->created_at); ?></p>
						<p><b>Email</b> : <?php echo e($arItems->email); ?></p>
						<p><b>Số điện thoại</b> : 0<?php echo e($arItems->phone); ?></p>
						<p><b>Hình thức thanh toán</b> : <?php echo e($arItems->hinhthuc); ?></p>
						<p><b style="font-size: 20px;">Tổng cộng</b> : <b><?php echo e(number_format($tt)); ?> VNĐ</b></p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div style="text-align: center">
		<a href="<?php echo e(route('public.giay.cancel',['id'=>$arItems->id])); ?>" style="margin-right:200px;font-size: 30px;">Hủy đơn hàng</a>
		<?php 
		if($arItems->hinhthuc == 'Ngân lượng'){
	?>
	<a target="_blank" href="https://www.nganluong.vn/button_payment.php?receiver=thimyvo18@gmail.com&product_name=<?php echo e($arItems->id); ?>&price=<?php echo e($tt); ?>&return_url=http://giayvtm.vn:8070/thanhcong/&comments=<?php echo e($arItems->ghichu); ?>"><img src="https://www.nganluong.vn/css/newhome/img/button/safe-pay-2.png" 	border="0" /></a>
	<?php 
	}elseif($arItems->hinhthuc == 'Bảo kim'){
	?>
	<a target="_blank" href="https://www.baokim.vn/payment/product/version11?business=thimyvo18%40gmail.com&id=&order_description=000&product_name=giay&product_price=<?php echo e($tt); ?>&product_quantity=1&total_amount=<?php echo e($tt); ?>&url_cancel=&url_detail=&url_success="><img src="http://www.baokim.vn/developers/uploads/baokim_btn/thanhtoan-l.png" alt="Thanh toán an toàn với Bảo Kim !" border="0" title="Thanh toán trực tuyến an toàn dùng tài khoản Ngân hàng (VietcomBank, TechcomBank, Đông Á, VietinBank, Quân Đội, VIB, SHB,... và thẻ Quốc tế (Visa, Master Card...) qua Cổng thanh toán trực tuyến BảoKim.vn" ></a>	
	<?php 
		}
	?>
	</div>
<?php echo $__env->make('templates.public.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
			
