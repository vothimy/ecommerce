<?php echo $__env->make('templates.public.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--start-ckeckout-->
	<div class="ckeckout">
		<div class="container">
			<div class="ckeckout-top">
			<div class=" cart-items heading">
			 <h3>túi hàng của bạn</h3>
				<script>$(document).ready(function(c) {
					$('.close1').on('click', function(c){
						$('.cart-header').fadeOut('slow', function(c){
							$('.cart-header').remove();
						});
						});	  
					});
			   </script>
			<script>$(document).ready(function(c) {
					$('.close2').on('click', function(c){
						$('.cart-header1').fadeOut('slow', function(c){
							$('.cart-header1').remove();
						});
						});	  
					});
			   </script>
			   <script>$(document).ready(function(c) {
					$('.close3').on('click', function(c){
						$('.cart-header2').fadeOut('slow', function(c){
							$('.cart-header2').remove();
						});
						});	  
					});
			   </script>
				
			<div class="in-check" >
				<ul class="unit">
					<li style="width:280px"><span>Mục</span></li>
					<li ><span>Tên sản phẩm</span></li>		
					<li><span>Giá</span></li>
					<li><span>Số lượng</span></li>
					<li> </li>
					<div class="clearfix"> </div>
				</ul>
				<ul class="cart-header">
					<div class="close1"> </div>
						<li class="ring-in"><a href="" ><img src="<?php echo e($publicUrl); ?>/images/s-1.jpg" class="img-responsive" alt=""></a>
						</li>
						<li><span>Woo Dress</span></li>
						<li><span>500.000đ</span></li>
						<li><span>In Stock</span></li>
						<!-- <li> <a href="" class="add-cart cart-check">ADD TO CART</a></li> -->
					<div class="clearfix"> </div>
				</ul>
				<ul class=" cart-header1">
					<div class="close2"> </div>
						<li class="ring-in"><a href="" ><img src="<?php echo e($publicUrl); ?>/images/s-2.jpg" class="img-responsive" alt=""></a>
						</li>
						<li><span>Elliot Shoes</span></li>
						<li><span>500.000đ</span></li>
						<li><span>In Stock</span></li>
						<div class="clearfix"> </div>
				</ul>
				<ul class="cart-header2">
					<div class="close3"> </div>
						<li class="ring-in"><a href="" ><img src="<?php echo e($publicUrl); ?>/images/s-4.jpg" class="img-responsive" alt=""></a>
						</li>
						<li><span>Woo Dress</span></li>
						<li><span>500.000đ</span></li>
						<li><span>In Stock</span></li>
						<div class="clearfix"> </div>
				</ul>
			</div>
			</div>  
		 </div>
		</div>
	</div>
	<!--end-ckeckout-->

<?php echo $__env->make('templates.public.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
  