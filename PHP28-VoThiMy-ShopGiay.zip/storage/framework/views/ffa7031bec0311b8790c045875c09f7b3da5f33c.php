<?php $__env->startSection('main-content'); ?>

<div class="content">
	<div class="women_main">
		<!-- start content -->
		<div class="grids">
			<div class="progressbar-heading grids-heading">
				<h2>Sửa thông tin nhân viên</h2>
			</div>
			<div class="panel panel-widget forms-panel">
				<div class="forms">
					<div class="form-grids widget-shadow" data-example-id="basic-forms"> 
						<!-- <div class="form-title">
							<h4>Basic Form :</h4>
						</div> -->
						<div class="form-body">
							<form action="" method="POST">
								<div class="form-group">
									<label for="exampleInputEmail1">Username</label> 
									<input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="Tên đăng nhập"> 
								</div> 
								<div class="form-group">
									<label for="exampleInputEmail1">Fullname</label> 
									<input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="Tên đầy đủ"> 
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Password</label> 
									<input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="Password"> 
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Địa chỉ</label> 
									<input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="Địa chỉ"> 
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Sđt</label> 
									<input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="Số điện thoại"> 
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Email</label> 
									<input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="Email"> 
								</div>
								<button type="submit" class="btn btn-default">Cập nhật</button> 
							</form> 
						</div>
					</div>
				</div>
			</div>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>