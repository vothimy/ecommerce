<?php echo $__env->make('templates.public.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--banner-starts-->
<div class="bnr" id="home">
    <div  id="top" class="callbacks_container">
        <ul class="rslides" id="slider4">
            <li>
                <div class="banner-1"></div>
            </li>
            <li>
                <div class="banner-2"></div>
            </li>
            <li>
                <div class="banner-3"></div>
            </li>
        </ul>
    </div>
    <div class="clearfix"> </div>
</div>
<!--banner-ends--> 
<!--Slider-Starts-Here-->
<script src="<?php echo e($publicUrl); ?>/js/responsiveslides.min.js"></script>
<script>
                // You can also use "$(window).load(function() {"
                $(function () {
                  // Slideshow 4
                  $("#slider4").responsiveSlides({
                    auto: true,
                    pager: true,
                    nav: false,
                    speed: 500,
                    namespace: "callbacks",
                    before: function () {
                      $('.events').append("<li>before event fired.</li>");
                  },
                  after: function () {
                      $('.events').append("<li>after event fired.</li>");
                  }
              });
                  
              });
          </script>
          <!--End-slider-script-->
          <!--start-shoes-->
          <!-- <div class="select-option"> -->
    <!-- <label>SẮP XẾP THEO :</label>
        <select class="select-pro">
            <option value="1">Sản phẩm nổi bật</option>
            <option value="2">Sản phẩm xem nhiều nhất</option>
        </select>
    </div>  -->
    <div class="shoes"> 
        <div class="container"> 
            <div class="product-one">
                <?php $__currentLoopData = $arItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 product-left"> 
                    <div class="p-one simpleCart_shelfItem">
                        <?php 
                        $nameSlug = str_slug($arItem->tensp);
                        ?>
                        <a href="<?php echo e(route('public.giay.chitiet',['slug'=>$nameSlug,'id'=>$arItem->id])); ?>">
                            <?php $__currentLoopData = $arHA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($arItem->id == $arha['id_sp']): ?>
                            <img src="<?php echo e($publicfiles); ?>/<?php echo e($arha->name); ?>" alt="" />
                            <?php break; ?>
                            <?php endif; ?>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="mask">
                                <span>Xem chi tiết</span>
                            </div>
                        </a>
                        <h4><?php echo e($arItem->tensp); ?></h4>
                        <p><a class="item_add" href="#"><i></i> <span class=" item_price"><?php echo e(number_format($arItem->gia)); ?> VNĐ</span></a></p>
                        
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="clearfix"> </div>
            </div>
            <?php echo e($arItems->links()); ?>

        </div>
    </div>
    
    <?php if(Session::has('msg')): ?>
    <script type="text/javascript">alert('<?php echo e(Session::get("msg")); ?>');</script>
    <?php endif; ?>

    <?php echo $__env->make('templates.public.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  