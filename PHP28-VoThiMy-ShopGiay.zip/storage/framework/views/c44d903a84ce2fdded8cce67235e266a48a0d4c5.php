
<?php echo $__env->make('templates.public.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="ckeckout">
	<div class="container">
		<div class="ckeckout-top">
			<div class=" cart-items heading">
				<h3>Giỏ hàng của bạn (<span id="countCart"><?php echo e(Cart::count(0)); ?></span> sản phẩm)</h3>
				<div class="in-check" >
					<ul class="unit">
						<li class="active"><span>SẢN PHẨM</span></li>
						<li><span>GIÁ</span></li>
						<li><span>SỐ LƯỢNG</span></li>
						<li><span>SIZE</span></li>
						<li><span>THÀNH TIỀN</span></li>
						<li><span>XÓA</span></li>
						<div class="clearfix"> </div>
					</ul>
					<form action="" method="POST">
						<?php echo e(csrf_field()); ?>

						<?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<ul class="cart-header2 cart-header3 sp<?php echo e($item->rowId); ?>">
							<li class="ring-in active">
								<?php 
								$nameSlug = str_slug($item->name);
								?>
								<a href="<?php echo e(route('public.giay.chitiet',['slug'=>$nameSlug,'id'=>$item->id])); ?>">
									<img src="<?php echo e($publicfiles); ?>/<?php echo e($item->options->img); ?>"  class="img-responsive" title="Bạn có muốn chọn lại size" alt="">
									<span class="cart-name">
										<?php echo e($item->name); ?>

									</span>
								</a>
							</li>
							<li><span style=" margin-top: 55px;"><?php echo e(number_format($item->price)); ?> đ</span></li>
							<li>
								<input type="number" name="" value="<?php echo e($item->qty); ?>" min="1" id="qty<?php echo e($item->rowId); ?>">
								<span>
									<a href="javascript:void(0)">
										<img src="<?php echo e($publicUrl); ?>/images/synchronization-arrows.png" class="updatecart icon-del" id="<?php echo e($item->rowId); ?>">
									</a>
								</span>
							</li>
							<li>
								<span  style=" margin-top: 55px;"><?php echo e($item->options->size); ?></span>
								
							</li>
							<li >
								<span  style=" margin-top: 55px;" id="tien<?php echo e($item->rowId); ?>"><?php echo e(number_format($item->price*$item->qty)); ?> đ</span>
							</li>
							<li>
								<span  style=" margin-top: 55px; margin-left: 37px;">
									<a href="javascript:void(0)">
										<img src="<?php echo e($publicUrl); ?>/images/recyclebin.png" class="delete icon" id="<?php echo e($item->rowId); ?>">
									</a>
								</span>
							</li>
							<div class="clearfix"> </div>
						</ul>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<ul class="cart-header2" style="list-style: none;background: #e5e5e5;font-family: arial !important">
							<li style="float: left; width: 200px !important;    margin-top: 10px;    margin-right: 236px;" >
								<a href="javascript:void(0)" class="del-all" >
									<img src="<?php echo e($publicUrl); ?>/images/recyclebin.png" class="delete icon"/>Xóa tất cả các sản phẩm
								</a>
							</li>
							<li style="font-size: 28px;width: 300px !important;float: left;">Tổng tiền : <p style="float: right;" id="totalCart"><?php echo e(Cart::total(0)); ?> đ</p style="float: right;"></li>
							<div class="clearfix"> </div>
						</ul>
					</form>
				</div>
			</div>  
		</div>
	</div>
</div>
<!--start-ckeckout-->

<div class="ttmh">
	<a href="<?php echo e(route('public.index.index')); ?>" id="ttmh">Tiếp tục mua hàng</a>
	<?php 
	if(Auth::user() == ''){
		?>
		<button class="btn btn-primary" id="ttmh1" data-toggle="modal" data-target="#myModal">
			Đặt hàng
		</button>
		<?php 
	}else{
		if(Cart::count() != 0){
		?>
		<a href="<?php echo e(route('public.giay.ordercustomer')); ?>" id="ttmh1" >Đặt hàng</a>
		<?php	
		}else{
		?>
		<a href="" id="ttmh1" >Đặt hàng</a>
		<?php }} ?>
	<?php if(Cart::count() != 0): ?>
	<!-- Modal -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
					<h4 class="modal-title" id="myModalLabel">ĐĂNG NHẬP</h4>
				</div>
				<div class="modal-body">
					<form action="<?php echo e(route('public.giay.loginmember')); ?>" method="POST">
						<?php echo e(csrf_field()); ?>

						<div class="form-group">
							<input type="text" name="username" required class="form-control" id="exampleInputEmail1" value="" placeholder="Username">
						</div>
						<div class="form-group">
							<input type="password" name="password" required class="form-control" id="exampleInputPassword1" value="" placeholder="Mật khẩu">
						</div>
						<button type="submit" class="btn btn-default">ĐĂNG NHẬP</button>
						<a href="<?php echo e(route('public.giay.ordercustomer')); ?>" title="Điền thông tin" class="btn btn-default" id="btn-default1">ĐẶT HÀNG KHÔNG CẦN ĐĂNG KÍ TÀI KHOẢN
						</a>
					</form>
				</div>
			</div>
		</div>
	</div>
	<?php else: ?>
	<script type="text/javascript">alert('Giỏ hàng đang rỗng');</script>
	<?php endif; ?>
</div>

<!-- end điền thông tiền -->
</div>
<hr>
<div class="product">
	<div class="container">
		<div class="product-main">
			<div class="col-md-12 p-left">
				<div class="product-one">
					<?php $__currentLoopData = $arItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-4 product-left single-left"> 
						<div class="p-one simpleCart_shelfItem">
							<?php 
							$nameSlug = str_slug($item->tensp);
							?>
							<a href="<?php echo e(route('public.giay.chitiet',['slug'=>$nameSlug,'id'=>$item->id])); ?>">
								<?php $__currentLoopData = $arHA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($item->id == $arha['id_sp']): ?>
								<img src="<?php echo e($publicfiles); ?>/<?php echo e($arha->name); ?>" alt="<?php echo e($item->tensp); ?>" />
								<?php break; ?>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<div class="mask mask1">
									<span>Xem chi tiết</span>
								</div>
							</a>
							<h4><?php echo e($item->tensp); ?></h4>
							<p><a class="item_add" href="#"><i></i> <span class=" item_price"><?php echo e($item->gia); ?></span></a></p>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<div class="clearfix"> </div>
				</div>

			</div>
			<?php echo e($arItems->links()); ?>

			<?php if(Session::has('msg')): ?>
			<script type="text/javascript">alert('<?php echo e(Session::get("msg")); ?>');</script>
			<?php endif; ?>
			<?php echo $__env->make('templates.public.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
			
