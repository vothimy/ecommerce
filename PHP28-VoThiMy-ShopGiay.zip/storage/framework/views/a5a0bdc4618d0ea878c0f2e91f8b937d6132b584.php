<?php $__env->startSection('main-content'); ?>
<div class="product">
	<div class="container">
		<div class="product-main">
			<div class="col-md-9 p-left">

				<div class="product-one">
					<?php $__currentLoopData = $arItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-4 product-left single-left"> 
						<div class="p-one simpleCart_shelfItem">
						<?php 
	                        $nameSlug = str_slug($item->tensp);
	                    ?>
							<a href="<?php echo e(route('public.giay.chitiet',['slug'=>$nameSlug,'id'=>$item->id])); ?>">
								<?php $__currentLoopData = $arHA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                <?php if($item->id == $arha['id_sp']): ?>
	                                <img src="<?php echo e($publicfiles); ?>/<?php echo e($arha->name); ?>" alt="<?php echo e($item->tensp); ?>" />
	                                <?php break; ?>
	                                <?php endif; ?>
                           		 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<div class="mask mask1">
									<span>Quick View</span>
								</div>
							</a>
							<h4><?php echo e($item->tensp); ?></h4>
							<p><a class="item_add" href="#"><i></i> <span class=" item_price"><?php echo e($item->gia); ?></span></a></p>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<div class="clearfix"> </div>
				</div>
				<?php echo e($arItems->links()); ?>

			</div>
			<?php if(Session::has('msg')): ?>
			<script type="text/javascript">alert('<?php echo e(Session::get("msg")); ?>');</script>
			<?php endif; ?>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.public.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>