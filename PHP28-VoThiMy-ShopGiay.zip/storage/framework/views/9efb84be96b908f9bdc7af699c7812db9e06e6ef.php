<?php $__env->startSection('main-content'); ?>
<!--start-breadcrumbs-->

<!--start-single-->
<div class="single contact">
	<div class="container">
		<div class="single-main">
			<div class="col-md-9 single-main-left">
				<div class="sngl-top">
					<div class="col-md-5 single-top-left">	
						<div class="flexslider">
							<ul class="slides">
								<?php $__currentLoopData = $arH; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li data-thumb="<?php echo e($publicfiles); ?>/<?php echo e($arh->name); ?>">
									<img src="<?php echo e($publicfiles); ?>/<?php echo e($arh->name); ?>" />
								</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
						<!-- FlexSlider -->
						<script defer src="<?php echo e($publicUrl); ?>/js/jquery.flexslider.js"></script>
						<link rel="stylesheet" href="<?php echo e($publicUrl); ?>/css/flexslider.css" type="text/css" media="screen" />

						<script>
							$(window).load(function() {
								$('.flexslider').flexslider({
									animation: "slide",
									controlNav: "thumbnails"
								});
							});
						</script>
					</div>	
					<div class="col-md-7 single-top-right">
						<div class="details-left-info simpleCart_shelfItem">
							<h3><?php echo e($arDetail->tensp); ?></h3>
							<div class="price_single">
								<!-- //<span class="reducedfrom">800.000đ</span> -->
								<span class="actual item_price"><?php echo e(number_format($arDetail->gia)); ?> VNĐ</span>
							</div>
							<h2 class="quick">Mô tả:</h2>
							<p class="quick_desc"><?php echo e($arDetail->mota); ?></p>
							<div class="quantity_box">
								<ul class="product-qty">
									<span>Kích cỡ:</span>
									<select id="bigcat">
										<option value="">--Chọn kích thước--</option>
										<?php $__currentLoopData = $arSL; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arsl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($arsl->soluong > 0): ?>
											<option value="<?php echo e($arsl->size); ?>"><?php echo e($arsl->size); ?></option>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</ul>
							</div>
							
							<div class="clearfix"> </div>
							<div class="single-but item_add">
								<a href="javascript:void(0)" title="Thêm sản phẩm vào giỏ hàng" id="<?php echo e($arDetail->id); ?>" class="addcart">Thêm vào giỏ</a>
							</div>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="latest products">

					<div class="product-one">
						<?php $__currentLoopData = $arDetail2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-3 product-left"> 
							<div class="p-one simpleCart_shelfItem">
								<?php 
								$nameSlug = str_slug($item->tensp);
								?>
								<a href="<?php echo e(route('public.giay.chitiet',['slug'=>$nameSlug,'id'=>$item->id])); ?>">
									<?php $__currentLoopData = $arHA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($item->id == $arha['id_sp']): ?>
									<img src="<?php echo e($publicfiles); ?>/<?php echo e($arha->name); ?>" alt="" />
									<?php break; ?>
									<?php endif; ?>
									
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<div class="mask">
										<span>Xem chi tiết</span>
									</div>
								</a>
								<h4><?php echo e($item->tensp); ?></h4>
								<p><a class="item_add" href="#"><i></i> <span class=" item_price"><?php echo e(number_format($item->gia)); ?> VNĐ</span></a></p>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="clearfix"> </div>
					</div>
				</div>
			</div>

			<!--end-single-->
			
			<?php $__env->stopSection(); ?> 


<?php echo $__env->make('templates.public.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>