<?php $__env->startSection('main-content'); ?>

<div class="content">
	<div class="women_main">
		<!-- start content -->
		<div class="grids">
			<div class="progressbar-heading grids-heading">
				<h2>Danh sách nhân viên</h2>
			</div>
			<div class="panel panel-widget forms-panel">
				<div class="forms">
					<div class="form-grids widget-shadow" data-example-id="basic-forms"> 
						<!-- <div class="form-title">
							<h4>Basic Form :</h4>
						</div> -->
						<a href="<?php echo e(route('admin.nvien.create')); ?>" class="addtop"><i class="fa fa-file-text-o"></i> Thêm</a>
						<div class="form-body">
							<table>
								<tr>
									<th style="width:10%">ID</th>
									<th style="width:40%">Tên nhân viên</th>
									<th style="width:40%">Tên đăng nhập</th>
									<th style="width:40%">Chức năng</th>
								</tr>
								<tr>
									<td>1</td>
									<td>Trần Văn A</td>
									<td>vana</td>
									<td><a href="<?php echo e(route('admin.nvien.edit')); ?>">Sửa</a> || <a href="">Xóa</a></td>
								</tr>
								<tr>
									<td>2</td>
									<td>Nguyễn Hoài Nam</td>
									<td>hoainam</td>
									<td><a href="">Sửa</a> || <a href="">Xóa</a></td>
								</tr>
								<tr>
									<td>3</td>
									<td>Phạm Văn Đồng</td>
									<td>vandong</td>
									<td><a href="">Sửa</a> || <a href="">Xóa</a></td>
								</tr>
							</table>
						</div>
					</div>
				</div>
			</div>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>