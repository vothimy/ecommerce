<?php $__env->startSection('main-content'); ?>

<div class="content">
	<div class="women_main">
		<!-- start content -->
		<div class="grids">
			<div class="progressbar-heading grids-heading">
				<h2>Phương thức thanh toán</h2>
			</div>
			<div class="panel panel-widget forms-panel">
				<div class="forms">
					<div class="form-grids widget-shadow" data-example-id="basic-forms"> 
						<?php if(Session::has('msg')): ?>
					    <div class="form-title"><?php echo e(Session::get('msg')); ?></div>
					    <?php endif; ?>
						<a href="<?php echo e(route('admin.pttt.create')); ?>" class="addtop"><img id="icon" src="<?php echo e($adminUrl); ?>/images/Add.png"> Thêm</a>
						<div class="form-body">
							<table>
								<tr>
									<th style="width:10%">ID</th>
									<th style="width:20%">Tên PTTT</th>
									<th style="width:30%">Chức năng</th>
								</tr>
								<?php $__currentLoopData = $arItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($arItem->id); ?></td>
									<td><?php echo e($arItem->name); ?></td>
									<td>
										<a href="<?php echo e(route('admin.pttt.edit',['id'=>$arItem->id])); ?>">
										<img id="icon" src="<?php echo e($adminUrl); ?>/images/Edit.png">
										Sửa	</a> || 
										<a href="<?php echo e(route('admin.pttt.destroy',['id'=>$arItem->id])); ?>" onclick="return xacNhanXoa()">
										<img id="icon" src="<?php echo e($adminUrl); ?>/images/Remove.png">Xóa
										</a></td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</table>
						</div>
					</div>
				</div>
			</div>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>