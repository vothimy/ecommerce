<?php $__env->startSection('main-content'); ?>

<div class="content">
	<div class="women_main">
		<!-- start content -->
		<div class="grids">
			<div class="progressbar-heading grids-heading">
				<h2>Chỉnh sửa giày</h2>
			</div>
			<?php if(count($errors) > 0): ?>
			<div class="alert alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
			<div class="panel panel-widget forms-panel">
				<div class="forms">
					<div class="form-grids widget-shadow" data-example-id="basic-forms"> 
						<div class="form-body">
							<form action="<?php echo e(route('admin.giay.edit',['id'=>$arItem->id])); ?>" method="POST">
								<?php echo e(csrf_field()); ?>

								<div class="form-group" style="width:500px;">
									<table>
										<tr>
											<td style="border-bottom: none">
												<label for="exampleInputEmail1" >Tên giày</label> 
												<input type="text" name="name" value="<?php echo e($arItem->tensp); ?>" class="form-control" id="exampleInputEmail1" placeholder="Tên giày"> 
											</td>
											<td style="border-bottom: none">
												<label for="exampleInputPassword1">Thuộc kiểu giày :</label> 
												<select style="height:35px;" name="id_kieu">
													<?php $__currentLoopData = $arCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php if($arItem->id_kieu == $arCat->id): ?>
													<option selected value="<?php echo e($arCat->id); ?>"><?php echo e($arCat->tenkieu); ?></option>
													<?php else: ?>
													<option><?php echo e($arCat->tenkieu); ?></option>
													<?php endif; ?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
											</td>
										</tr>
									</table>
								</div> 
								<div class="form-group" style="width:800px">
									<table>
										<tr>
											<td style="border-bottom: none">
												<label for="exampleInputEmail1">Giá</label> 
												<input type="text" name="gia" value="<?php echo e($arItem->gia); ?>" class="form-control" id="exampleInputEmail1" placeholder="Giá giày"> 
											</td>
											<td style="border-bottom: none">
												<label for="exampleInputFile">Chọn ảnh mới</label> 
												<input type="file" name="hinh[]" multiple id="exampleInputFile">
											</td>
											
										</td>
										<?php $__currentLoopData = $arHA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($arItem->id == $item['id_sp']): ?>
										<td style="border-bottom: none">
											<label for="exampleInputFile">Hình ảnh cũ:</label> 
											<img src="<?php echo e($publicfiles); ?>/<?php echo e($item['name']); ?>" style="width:70px;height:70px;">
										</td>
										<?php break; ?>;
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tr>
								</table>
							</div>
							<div class="form-group" style="width:600px">
								<table>

									<tr>
										<?php $__currentLoopData = $arSL; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemSL): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($itemSL->size == 37): ?>
										<td style="border-bottom: none">
											<label for="exampleInputEmail1">Số lượng : Size 37</label> 
											<input type="text" name="sl37" class="form-control" id="exampleInputEmail1" placeholder="size 37" value="<?php echo e($itemSL->soluong); ?> "> 
										</td>
										<?php elseif($itemSL->size == 38): ?>
										<td style="border-bottom: none">
											<label for="exampleInputEmail1">Số lượng : Size 38</label> 
											<input type="text" name="sl38" class="form-control" id="exampleInputEmail1" placeholder="size 38" value="<?php echo e($itemSL->soluong); ?> "> 
										</td>
										<?php elseif($itemSL->size == 39): ?>
										<td style="border-bottom: none">
											<label for="exampleInputEmail1">Số lượng : Size 39</label> 
											<input type="text" name="sl39" class="form-control" id="exampleInputEmail1" placeholder="size 39" value="<?php echo e($itemSL->soluong); ?> "> 
										</td>
										<?php elseif($itemSL->size == 40): ?>
										<td style="border-bottom: none">
											<label for="exampleInputEmail1">Số lượng : Size 40</label> 
											<input type="text" name="sl40" class="form-control" id="exampleInputEmail1" placeholder="size 40" value="<?php echo e($itemSL->soluong); ?> "> 
										</td>
										<?php elseif($itemSL->size == 41): ?>
										<td style="border-bottom: none">
											<label for="exampleInputEmail1">Số lượng : Size 41</label> 
											<input type="text" name="sl41" class="form-control" id="exampleInputEmail1" placeholder="size 41" value="<?php echo e($itemSL->soluong); ?> "> 
										</td>
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									</tr>
								</table>
							</div> 
							<div class="form-group" style="width:500px">
								<label for="exampleInputEmail1">Mô tả</label>
								<textarea name="mota" class="form-control" id="exampleInputEmail1"><?php echo e($arItem->mota); ?></textarea>
							</div>
							<button type="submit" class="btn btn-default">Cập nhật</button>

						</form> 
					</div>
				</div>
			</div>
		</div>
		<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>