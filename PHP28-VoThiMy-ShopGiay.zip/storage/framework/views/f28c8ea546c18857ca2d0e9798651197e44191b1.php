<?php $__env->startSection('main-content'); ?>

<div class="content">
	<div class="women_main">
		<!-- start content -->
		<div class="grids">
			<div class="progressbar-heading grids-heading">
				<h2>Các loại giày</h2>
			</div>
			<div class="panel panel-widget forms-panel">
				<div class="forms">
					<div class="form-grids widget-shadow" data-example-id="basic-forms"> 
						<?php if(Session::has('msg')): ?>
						<div class="form-title" style="margin-bottom: 20px;"><?php echo e(Session::get('msg')); ?></div>
						<?php endif; ?>
						<a href="<?php echo e(route('admin.loaigiay.create')); ?>" class="addtop"><img id="icon" src="<?php echo e($adminUrl); ?>/images/Add.png"> Thêm</a>
						<div class="form-body">
							<table>
								<tr>
									<th>ID</th>
									<th style="width:40%">Tên loại</th>
									<th style="width:40%">Chức năng</th>
								</tr>
								<?php $__currentLoopData = $arItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($arItem->id); ?></td>
									<td><?php echo e($arItem->tenloai); ?></td>
									<td>
										<a href="<?php echo e(route('admin.loaigiay.edit',['id'=>$arItem->id])); ?>">
										<img id="icon" src="<?php echo e($adminUrl); ?>/images/Edit.png">
										Sửa</a> || 
										<img id="icon" src="<?php echo e($adminUrl); ?>/images/Remove.png">
										<a href="<?php echo e(route('admin.loaigiay.destroy',['id'=>$arItem->id])); ?>">Xóa
										</a>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</table>
						</div>
					</div>
				</div>
			</div>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>