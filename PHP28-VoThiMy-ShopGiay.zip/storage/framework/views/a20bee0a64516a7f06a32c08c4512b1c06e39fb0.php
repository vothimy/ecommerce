<?php $__env->startSection('main-content'); ?>

<div class="content">
	<div class="women_main">
		<!-- start content -->
		<div class="grids">
			<div class="progressbar-heading grids-heading">
				<h2>Sửa User</h2>
			</div>

			<?php if(count($errors) > 0): ?>
			  <div class="alert alert-danger">
			    <ul>
			      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			      <li><?php echo e($error); ?></li>
			      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			    </ul>
			  </div>
			<?php endif; ?>
			<div class="panel panel-widget forms-panel">
				<div class="forms">
					<div class="form-grids widget-shadow" data-example-id="basic-forms"> 
						<div class="form-body">
							<form action="<?php echo e(route('admin.user.edit',['id'=>$arItem->id])); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

								<div class="form-group" style="width:400px">
									<label for="exampleInputEmail1">Username</label> 
									<input type="text" readonly="readonly" name="username" value="<?php echo e($arItem->username); ?>" class="form-control" id="exampleInputEmail1" placeholder="Username"> 
								</div> 
								<div class="form-group" style="width:400px">
									<label for="exampleInputEmail1">Password</label> 
									<input type="password" name="password" class="form-control" id="exampleInputEmail1" placeholder="Password"> 
								</div> 
								<div class="form-group" style="width:400px">
									<label for="exampleInputEmail1">Fullname</label> 
									<input type="text" name="fullname" value="<?php echo e($arItem->fullname); ?>" class="form-control" id="exampleInputEmail1" placeholder="Fullname"> 
								</div> 
								<button type="submit" class="btn btn-default">Cập nhật</button> 
							</form> 
						</div>
					</div>
				</div>
			</div>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>