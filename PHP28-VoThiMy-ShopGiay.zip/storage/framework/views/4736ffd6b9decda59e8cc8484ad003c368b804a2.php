<div class="col-md-3 single-right">
  <h3>Kiểu giày</h3>
  <ul class="product-categories">
    <?php $__currentLoopData = $arKieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arkieu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php 
    $nameslug = str_slug($arkieu->tenkieu);
    $url = route('public.giay.danhmuc',['slug' => $nameslug, 'id' => $arkieu->id]);
    ?>
    <li><a href="<?php echo e($url); ?>"><?php echo e($arkieu->tenkieu); ?></a> </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>

          <!-- <h3>Giá</h3>
          <ul class="product-categories p1">
            <li><a href="#">100.000đ-200.000đ</a> <span class="count">(14)</span></li>
            <li><a href="#">200.000đ-300.000đ</a> <span class="count">(14)</span></li>
            <li><a href="#">300.000đ-400.000đ</a> <span class="count">(14)</span></li>
            <li><a href="#">400.000đ-500.000đ</a> <span class="count">(14)</span></li>
            <li><a href="#">500.000đ-600.000đ</a> <span class="count">(14)</span></li>
          </ul> -->
</div>