<?php $__env->startSection('main-content'); ?>

<div class="content">
	<div class="women_main">
		<!-- start content -->
		<div class="grids">
			<div class="progressbar-heading grids-heading">
				<h2>Thêm kiểu giày</h2>
			</div>
			<?php if(count($errors) > 0): ?>
			  <div class="alert alert-danger">
			    <ul>
			      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			      <li><?php echo e($error); ?></li>
			      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			    </ul>
			  </div>
			  <?php endif; ?>
			<div class="panel panel-widget forms-panel">
				<div class="forms">
					<div class="form-grids widget-shadow" data-example-id="basic-forms"> 
						<div class="form-body">
							<form action="<?php echo e(route('admin.kieugiay.create')); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

								<div class="form-group">
									<label for="exampleInputEmail1">Tên kiểu giày</label> 
									<input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="Tên loại giày"> 
								</div> 
								<div class="form-group"> 
				                    <label for="exampleInputPassword1">Thuộc loại giày :</label> 
				                    <select name="id_loai">
				                    	<option>--loại giày--</option>

				                    	<?php $__currentLoopData = $arCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                    	 	<option value="<?php echo e($arCat->id); ?>"><?php echo e($arCat->tenloai); ?></option>
				                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                    </select>
				                </div> 
								<button type="submit" class="btn btn-default">Thêm</button> 
							</form> 
						</div>
					</div>
				</div>
			</div>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>