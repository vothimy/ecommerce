<?php $__env->startSection('main-content'); ?>

<div class="content">
	<div class="women_main">
		<!-- start content -->
		<div class="grids">
			<div class="progressbar-heading grids-heading">
				<h2>Danh sách giày</h2>
			</div>
			<div class="panel panel-widget forms-panel">
				<div class="forms">
					<div class="form-grids widget-shadow" data-example-id="basic-forms"> 
						<?php if(Session::has('msg')): ?>
					    <div class="form-title"><?php echo e(Session::get('msg')); ?></div>
					    <?php endif; ?>
						<a href="<?php echo e(route('admin.giay.create')); ?>" class="addtop">
							<img id="icon" src="<?php echo e($adminUrl); ?>/images/Add.png">
							 Thêm
						 </a>
						<div class="form-body">
							<table>
								<tr>
									<th style="width:5%">ID</th>
									<th style="width:25%">Tên giày</th>
									<th style="width:15%">Giá (VNĐ) </th>
									<th style="width:5%">Số lượng </th>
									<th style="width:10%">Hình ảnh </th>
									<th style="width:20%">Thuộc kiểu</th>
									<th style="width:30%; text-align: center" >Chức năng</th>
								</tr>
								<?php $__currentLoopData = $arItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($arItem->id); ?></td>
									<td><?php echo e($arItem->tensp); ?></td>
									<td><?php echo e(number_format($arItem->gia)); ?></td>
									<td><?php echo e($arItem->soluong); ?></td>
									 <?php $__currentLoopData = $arHA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								 		<?php if($arItem->id == $item['id_sp']): ?>
								 				<td><img src="<?php echo e($publicfiles); ?>/<?php echo e($item['name']); ?>" style="width:70px;height:70px;"></td>
								 				<?php break; ?>;
								 		<?php endif; ?>
									 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
									<td><?php echo e($arItem->tenkieu); ?></td>
									<td>
										<a href="<?php echo e(route('admin.giay.edit',['id'=>$arItem->id])); ?>">
											<img id="icon" src="<?php echo e($adminUrl); ?>/images/Edit.png">
											 Sửa
										</a> || 
										<a href="<?php echo e(route('admin.giay.destroy',['id'=>$arItem->id])); ?>">
											<img id="icon" src="<?php echo e($adminUrl); ?>/images/Remove.png">

										 Xóa
										</a>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
							</table>
						</div>
						<ul class="pagination">
              				 <?php echo e($arItems->links()); ?>

               			 </ul>
					</div>
				</div>
			</div>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>